﻿using guessGame.Model;
using Microsoft.EntityFrameworkCore;

////////////////////////////////////Hussein El Mazbouh///////////////////////////////////////////

namespace guessGame.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<GameDataModel> GameDb { get; set; }
    }
}
