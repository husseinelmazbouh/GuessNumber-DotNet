using guessGame.Data;
using guessGame.Model;
using guessGame.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace guessGame.Pages
{
    ////////////////////////////////////Hussein El Mazbouh///////////////////////////////////////////
    ///
    public class IndexModel : PageModel
    {
        [BindProperty]
        public GameBindingModel bind { get; set; }
        public GameViewModel view { get; set; }
        private readonly AppDbContext context;
        private readonly GameService _gameService;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger, GameService gameService, AppDbContext context)
        {
            _logger = logger;
            _gameService = gameService;
            this.context = context;
        }



        public void OnGet()
        {

        }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }


            //var Game = await context.GameDb.FindAsync(bind.Id);

            if (bind == null)
            {
                ModelState.AddModelError(string.Empty, "Game ID does not exist");
                return Page();
            }
            if (bind.A > bind.B)
            {
                ModelState.AddModelError(string.Empty, "A must be less than B.");
                return Page();
            }
            if (bind.B % 2 != 0)
            {
                ModelState.AddModelError(string.Empty, "B must be multiple of 2");
                return Page();
            }
            string winner = "Bot";
            int playerscore = bind.A + bind.B;
            int botscore = bind.X + bind.Y;
            int al = await _gameService.winner(bind);
            if (al == 1)
            {
                winner = "Bot";
            }
            else if (al == 0)
            {
                winner = "Player";
            }
            int Game = await _gameService.Save(bind, winner, playerscore, botscore);


            return RedirectToPage("/Results", new { id = Game });

        }
    }
}
