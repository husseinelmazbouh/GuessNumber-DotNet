﻿using System.ComponentModel.DataAnnotations;

////////////////////////////////////Hussein El Mazbouh///////////////////////////////////////////

namespace guessGame.Model
{
    public class GameDataModel
    {
        [Key]
        public int Id { get; set; }
        public int A { get; set; }
        public int B { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int PlayerScore { get; set; }
        public int BotScore { get; set; }
        public DateTime GameTime { get; set; } = DateTime.Now;
        public string winner { get; set; }
    }
}
