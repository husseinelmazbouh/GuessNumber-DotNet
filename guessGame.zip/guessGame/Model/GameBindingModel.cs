﻿using System.ComponentModel.DataAnnotations;

////////////////////////////////////Hussein El Mazbouh///////////////////////////////////////////

namespace guessGame.Model
{
    public class GameBindingModel
    {
        [Required]
        public int Id { get; set; }
        [Required]
        [Range(1, 10)]
        public int A { get; set; }
        [Required]
        [Range(1, 10)]
        public int B { get; set; }
        [Required]
        public int X { get; set; }
        [Required]
        public int Y { get; set; }
        //public int PlayerScore { get; set; }
        //public int BotScore { get; set; }
        //public string winner { get; set; }

    }
}
