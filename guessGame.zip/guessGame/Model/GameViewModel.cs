﻿using System.ComponentModel.DataAnnotations;

////////////////////////////////////Hussein El Mazbouh///////////////////////////////////////////

namespace guessGame.Model
{
    public class GameViewModel
    {
        [Required]
        [Range(1, 10, ErrorMessage = "Value of A must be between and 10")]
        [Display(Name = "Value A:")]
        public int A { get; set; }
        [Required]
        [Range(1, 10, ErrorMessage = "Value of B must be between and 10")]
        [Display(Name = "Value B:")]
        public int B { get; set; }
    }
}
