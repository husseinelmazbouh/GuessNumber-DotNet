using guessGame.Data;
using guessGame.Service;
using Microsoft.EntityFrameworkCore;


////////////////////////////////////Hussein El Mazbouh///////////////////////////////////////////


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<GameService>();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("GameDb"));
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}
app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();
app.MapPost("/play/{A}/{B}", (int A, int B) => {
    var rnd = new Random();
    int X = rnd.Next(1, 11);
    int Y = rnd.Next(1, 11);
    int playerScore = A + B;
    int botScore = rnd.Next(5, 15);
    string winner = playerScore > botScore ? "Player" : "Bot";


    return Results.Ok(new { A, B, X, Y, PlayerScore = playerScore, BotScore = botScore, Winner = winner });
}).AddEndpointFilter<Filter>();

app.MapGet("/myName", () =>
{
    Results.Ok("Hussein El Mazbouh");
});

app.Run();
public class Filter : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var A = context.GetArgument<int>(0);
        var B = context.GetArgument<int>(1);

        if (A < 1 || B < 1)
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                { "A", new[] { "A must be greater than or equal to 1." } },
                { "B", new[] { "B must be greater than or equal to 1." } }
            });
        if (A > 10 || B > 10)
            return Results.ValidationProblem(new Dictionary<string, string[]> {
                {"A", new[] { "A must be less than or equal to 10." } },
                { "B", new[] { "B must be less than or equal to 10." }
                }
            });
        if (A >= B)
            return Results.ValidationProblem(new Dictionary<string, string[]> {
                {"A", new[] { "A must be less than B." } },
                { "B", new[] { "B must be greater than A." } }
            });
        if (B % 2 != 0)
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                { "B", new[] { "B must be a multiple of 2." } }
            }
                );

        return await next(context);
    }
}


