﻿using guessGame.Data;
using guessGame.Model;

////////////////////////////////////Hussein El Mazbouh///////////////////////////////////////////

namespace guessGame.Service
{
    public class GameService
    {
        public readonly AppDbContext context;
        public GameService(AppDbContext context)
        {
            this.context = context;
        }

        public async Task<int> winner(GameBindingModel bind)
        {
            //var Game = await context.GameDb.FindAsync(bind.Id);
            if (bind.A + bind.B > bind.X + bind.Y)
            {
                int PlayerScoree = bind.A + bind.B;
                int BotScoree = bind.X + bind.Y;
                return 0;
            }
            int PlayerScore = bind.A + bind.B;
            int BotScore = bind.X + bind.Y;
            return 1;
        }
        public async Task<int> Save(GameBindingModel bind, string winner, int PlayerScore, int BotScore)
        {
            GameDataModel data = new GameDataModel
            {
                A = bind.A,
                B = bind.B,
                X = bind.X,
                Y = bind.Y,
                PlayerScore = PlayerScore,
                BotScore = BotScore,
                winner = winner
            };
            context.GameDb.Add(data);
            await context.SaveChangesAsync();
            return data.Id;
        }
    }
}
